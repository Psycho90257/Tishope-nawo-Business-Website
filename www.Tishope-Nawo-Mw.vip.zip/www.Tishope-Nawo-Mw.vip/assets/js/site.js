// Tishope Nawo: shared site script
// ===== CONFIGURE HERE =====
// WhatsApp number in international format, digits only (no +, spaces or dashes).
var WHATSAPP_NUMBER = "265997681231";

function waLink(msg) {
    return "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(msg);
}

document.addEventListener("DOMContentLoaded", function () {
    // Logo: show the logo if images/logo.png exists, otherwise show the business name as text
    var logo = document.querySelector(".brand-logo");
    if (logo) {
        var root = document.documentElement;
        var probe = new Image();
        probe.onload = function () { root.classList.add("has-logo"); };
        probe.onerror = function () { root.classList.add("no-logo"); };
        probe.src = logo.getAttribute("src");
    }

    // Footer year
    var year = document.getElementById("year");
    if (year) year.textContent = new Date().getFullYear();

    // WhatsApp links
    document.querySelectorAll(".js-wa").forEach(function (el) {
        el.href = waLink(el.getAttribute("data-msg") || "Hello!");
        el.target = "_blank";
        el.rel = "noopener noreferrer";
    });

    // Placeholder for missing product images
    var PLACEHOLDER = "data:image/svg+xml;utf8," + encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300"><rect width="100%" height="100%" fill="#e5eaf0"/>' +
        '<text x="50%" y="50%" fill="#7b8794" font-family="Arial" font-size="20" text-anchor="middle">Image coming soon</text></svg>');
    document.querySelectorAll(".card img").forEach(function (img) {
        img.addEventListener("error", function () { if (img.src !== PLACEHOLDER) img.src = PLACEHOLDER; });
        if (img.complete && img.naturalWidth === 0) img.src = PLACEHOLDER;
    });

    // Product category filter
    var filters = document.querySelectorAll(".filter-btn");
    filters.forEach(function (btn) {
        btn.addEventListener("click", function () {
            var cat = btn.getAttribute("data-filter");
            filters.forEach(function (b) { b.classList.toggle("active", b === btn); b.setAttribute("aria-pressed", b === btn); });
            document.querySelectorAll(".grid .card").forEach(function (card) {
                card.hidden = !(cat === "all" || card.getAttribute("data-cat") === cat);
            });
        });
    });

    // Contact form: opens WhatsApp with the message
    var form = document.getElementById("contact-form");
    if (form) {
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            var name = form.elements["name"].value.trim();
            var message = form.elements["message"].value.trim();
            window.open(waLink("Hello Tishope Nawo, my name is " + name + ". " + message), "_blank", "noopener");
            form.reset();
        });
    }
});
